﻿using EventsManagementPortal.Entities;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace EventsManagementPortal.Dal
{
    public class CommonRepository<T> : ICommonRepository<T> where T : class
    {
        private readonly WebPoCHubEventsDbEntities dbContext = null;
        private DbSet<T> table = null;
        public CommonRepository()
        {
            dbContext = new WebPoCHubEventsDbEntities();
            table = dbContext.Set<T>();
        }
        public List<T> GetAll()
        {
            return table.ToList();
        }
        public T GetDetails(int id)
        {
            return table.Find(id);
        }
        public void Insert(T item)
        {
            table.Add(item);
        }
        public void Update(int id, T item)
        {
            table.Attach(item);
            dbContext.Entry(item).State = EntityState.Modified;
        }
        public void Delete(T item)
        {
            table.Remove(item);
        }
        public int SaveChanges()
        {
            return dbContext.SaveChanges();
        }
        public List<GetAllEmployees_Result> GetAllEmployeesSP()
        {
            return dbContext.GetAllEmployees().ToList();
        }
        public GetEmployeeDetails_Result GetEmployeeDetailsSP(int id)
        {
            return dbContext.GetEmployeeDetails(id).FirstOrDefault();
        }
    }
}

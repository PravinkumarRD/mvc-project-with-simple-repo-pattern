﻿using EventsManagementPortal.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventsManagementPortal.Dal
{
    public class EmployeeDal : IEmployeeDal
    {
        public IEnumerable<Employee> GetEmployees()
        {
            try
            {
                using (WebPoCHubEventsDbEntities dataContext = new WebPoCHubEventsDbEntities())
                {
                    return dataContext.Employees.ToList();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public Employee GetEmployeeDetails(int employeeId)
        {
            try
            {
                using (WebPoCHubEventsDbEntities dataContext = new WebPoCHubEventsDbEntities())
                {
                    return dataContext.Employees.Find(employeeId);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}

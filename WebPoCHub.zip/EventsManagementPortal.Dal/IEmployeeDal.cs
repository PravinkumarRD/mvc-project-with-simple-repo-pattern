﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EventsManagementPortal.Entities;

namespace EventsManagementPortal.Dal
{
    public interface IEmployeeDal
    {
        IEnumerable<Employee> GetEmployees();
        Employee GetEmployeeDetails(int employeeId);
    }
}

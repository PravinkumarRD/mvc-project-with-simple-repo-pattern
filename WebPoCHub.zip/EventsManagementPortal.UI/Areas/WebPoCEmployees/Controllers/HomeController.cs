﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EventsManagementPortal.Dal;
using EventsManagementPortal.Entities;

namespace EventsManagementPortal.UI.Areas.WebPoCEmployees.Controllers
{
    public class HomeController : Controller
    {
        private readonly IEmployeeDal employeeDal;
        public HomeController()
        {
            employeeDal = new EmployeeDal();
        }
        public ActionResult Index()
        {
            ViewBag.PageTitle = "Welcome To WebPoCHub Employees List!";
            ViewBag.SubTitle = "Core Employees List  Of WebPoCHub Global Teams!";
            var employees = employeeDal.GetEmployees();
            return View(employees);
        }
        public ActionResult Details(int id)
        {
            ViewBag.PageTitle = "Details Of - ";
            var employee = employeeDal.GetEmployeeDetails(id);
            return View(employee);
        }
    }
}
﻿using System.Web.Mvc;

namespace EventsManagementPortal.UI.Areas.WebPoCEvents
{
    public class WebPoCEventsAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "WebPoCEvents";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "WebPoCEvents_default",
                "WebPoCEvents/{controller}/{action}/{id}",
                new { controller = "Home", action = "Index", id = UrlParameter.Optional },
                new string[] { "EventsManagementPortal.UI.Areas.WebPoCEvents.Controllers" }
            );
        }
    }
}
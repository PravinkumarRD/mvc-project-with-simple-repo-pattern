﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EventsManagementPortal.UI.Areas.WebPoCSecurity.Controllers
{
    public class HomeController : Controller
    {
        // GET: WebPoCSecurity/Home
        public ActionResult Index()
        {
            ViewBag.PageTitle = "Welcome To WebPoCHub Authentication!";
            ViewBag.SubTitle = "Please submit your credentials to validate!";
            return View();
        }
    }
}
﻿using System.Web.Mvc;

namespace EventsManagementPortal.UI.Areas.WebPoCSecurity
{
    public class WebPoCSecurityAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "WebPoCSecurity";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "WebPoCSecurity_default",
                "WebPoCSecurity/{controller}/{action}/{id}",
                new { controller = "Home", action = "Index", id = UrlParameter.Optional },
                new string[] { "EventsManagementPortal.UI.Areas.WebPoCSecurity.Controllers" }
            );
        }
    }
}